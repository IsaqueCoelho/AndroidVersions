package com.example.isaquecoelho.androidversions.repositories;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.isaquecoelho.androidversions.modal.Android;

import java.util.List;

@Dao
public interface AndroidDao {

    @Insert
    void insert(Android android);

    @Query("SELECT `name`, `version`, `image` FROM `android` ")
    LiveData<List<Android>> getAllAndroid();
}
