package com.example.isaquecoelho.androidversions.repositories;

import android.arch.persistence.db.SupportSQLiteDatabase;
import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;
import android.os.AsyncTask;
import android.support.annotation.NonNull;

import com.example.isaquecoelho.androidversions.R;
import com.example.isaquecoelho.androidversions.modal.Android;

@Database(entities = {Android.class}, version = 1)
public abstract class AndroidDatabase extends RoomDatabase {

    private static AndroidDatabase instance;

    public abstract AndroidDao androidDao();

    public static synchronized AndroidDatabase getInstance(Context context){
        if(instance == null){
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    AndroidDatabase.class,
                    "android_database" )
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return instance;
    }

    private static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
        }
    };

    private static class PopulateDbAsynkTask extends AsyncTask<Void, Void, Void>{

        private AndroidDao androidDao;

        private PopulateDbAsynkTask(AndroidDatabase androidDatabase){
            androidDao = androidDatabase.androidDao();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            androidDao.insert(new Android("Cupcake", "V1.5", R.drawable.ic_1));
            androidDao.insert(new Android("Eclair", "V2.0", R.drawable.ic_2));
            androidDao.insert(new Android("Honeycomb", "V3.0", R.drawable.ic_3));
            androidDao.insert(new Android("KitKat", "V4.4", R.drawable.ic_4));
            androidDao.insert(new Android("Lollipop", "V5.0", R.drawable.ic_5));
            androidDao.insert(new Android("Marshmallow", "V6.0", R.drawable.ic_6));
            androidDao.insert(new Android("Nougat", "V7.0", R.drawable.ic_7));
            androidDao.insert(new Android("Oreo", "V8.0", R.drawable.ic_8));
            androidDao.insert(new Android("Pie", "V9.0", R.drawable.ic_9));
            return null;
        }
    }
}
