package com.example.isaquecoelho.androidversions.repositories;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;

import com.example.isaquecoelho.androidversions.modal.Android;

import java.util.List;

public class AndroidRepository2 {

    private AndroidDao mAndroidDao;
    private LiveData<List<Android>> AndroidList;

    public AndroidRepository2(Application application) {
        AndroidDatabase database = AndroidDatabase.getInstance(application);
        mAndroidDao = database.androidDao();
        AndroidList = mAndroidDao.getAllAndroid();
    }

    public void insert(Android android){

    }

    public LiveData<List<Android>> getAndroidList() {
        return AndroidList;
    }

    private static class InsertAndroidAsyncTask extends AsyncTask<Android, Void, Void>{

        private AndroidDao androidDao;

        public InsertAndroidAsyncTask(AndroidDao androidDao) {
            this.androidDao = androidDao;
        }

        @Override
        protected Void doInBackground(Android... androids) {
            androidDao.insert(androids[0]);
            return null;
        }
    }
}
