package com.example.isaquecoelho.androidversions.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.support.annotation.NonNull;

import com.example.isaquecoelho.androidversions.modal.Android;
import com.example.isaquecoelho.androidversions.repositories.AndroidRepository;
import com.example.isaquecoelho.androidversions.repositories.AndroidRepository2;

import java.util.List;

public class MainActivityViewModal extends AndroidViewModel{

    private AndroidRepository2 repository2;
    private LiveData<List<Android>> androidList;
    private MutableLiveData<List<Android>> mAndroidList;

    public MainActivityViewModal(@NonNull Application application) {
        super(application);
        repository2 = new AndroidRepository2(application);
        androidList = repository2.getAndroidList();
    }

    public LiveData<List<Android>> getAndroidList(){
        return androidList;
    }

    /*public void init(){

        if (mAndroidList != null){
            return;
        }

        AndroidRepository mAndroidRepository = AndroidRepository.getInstance();
        mAndroidList = mAndroidRepository.getAndroidList();
    }

    public LiveData<List<Android>> getmAndroidList(){
        return mAndroidList;
    }*/
}
